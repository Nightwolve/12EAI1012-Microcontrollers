/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <cytypes.h>

#define FIFO_F0 0;
#define FIFO_F1 1;

void WS2812driver_1_write_byte(unsigned char buff);
void WS2812driver_1_write2fifo(unsigned char* buff, unsigned char len);

/* [] END OF FILE */
